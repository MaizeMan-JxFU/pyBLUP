Installation
```bash
pip install git+https://github.com/MaizeMan-JxFU/pyBLUP.git
```
Usage
```python
from pyBLUP import BLUP
```
